// Apex Signal Trading — Extension Popup State & Controller
document.addEventListener("DOMContentLoaded", () => {
  // Navigation / Views
  const authView = document.getElementById("auth-view");
  const mainView = document.getElementById("main-view");
  const btnLogout = document.getElementById("btn-logout");

  // Auth View Elements
  const btnCheckSession = document.getElementById("btn-check-session");
  const textCheckSession = document.getElementById("text-check-session");
  const iconRefresh = document.getElementById("icon-refresh");

  // Main Dashboard Elements
  const sessionUser = document.getElementById("session-user");
  const tabDot = document.getElementById("tab-dot");
  const tabText = document.getElementById("tab-text");
  const linkOpenQuotex = document.getElementById("link-open-quotex");

  const btnToggleMonitoring = document.getElementById("btn-toggle-monitoring");
  const iconPlay = document.getElementById("icon-monitoring-play");
  const iconStop = document.getElementById("icon-monitoring-stop");
  const monitoringTitle = document.getElementById("monitoring-title");
  const monitoringSub = document.getElementById("monitoring-sub");

  const valAsset = document.getElementById("val-asset");
  const valAssetStatus = document.getElementById("val-asset-status");
  const tagMarketMode = document.getElementById("tag-market-mode");

  let currentMonitoringState = false;

  // Update Market Badge based on detected pair
  function updateAssetDisplay(pairName) {
    if (!pairName || pairName === "Auto-Detecting...") {
      valAsset.textContent = "Auto-Detecting...";
      valAssetStatus.textContent = "Open Quotex chart to detect active pair";
      tagMarketMode.textContent = "SCANNING";
      tagMarketMode.className = "tag-live";
      return;
    }

    valAsset.textContent = pairName;
    const isOTC = pairName.toUpperCase().includes("OTC");
    tagMarketMode.textContent = isOTC ? "OTC MARKET" : "REGULAR MARKET";
    valAssetStatus.textContent = currentMonitoringState
      ? "Streaming real-time chart ticks to decision engine"
      : "Monitoring paused · Asset synced";
  }

  // Update UI for Monitoring State (Active vs Idle)
  function renderMonitoringState(isActive) {
    currentMonitoringState = !!isActive;

    if (currentMonitoringState) {
      btnToggleMonitoring.classList.remove("state-idle");
      btnToggleMonitoring.classList.add("state-active");
      iconPlay.classList.add("hidden");
      iconStop.classList.remove("hidden");
      monitoringTitle.textContent = "MONITORING ACTIVE";
      monitoringSub.textContent = "Streaming live chart data · Click to pause";
      if (valAsset.textContent && valAsset.textContent !== "Auto-Detecting...") {
        valAssetStatus.textContent = "Streaming real-time chart ticks to decision engine";
      }
    } else {
      btnToggleMonitoring.classList.remove("state-active");
      btnToggleMonitoring.classList.add("state-idle");
      iconStop.classList.add("hidden");
      iconPlay.classList.remove("hidden");
      monitoringTitle.textContent = "START MONITORING";
      monitoringSub.textContent = "Capture paused · Click to start";
      if (valAsset.textContent && valAsset.textContent !== "Auto-Detecting...") {
        valAssetStatus.textContent = "Monitoring paused · Asset synced";
      }
    }
  }

  // Check Quotex Tab status in browser
  function checkBrokerTabStatus() {
    if (!chrome?.tabs?.query) {
      tabText.textContent = "Quotex Sync Ready";
      tabDot.className = "dot dot-green";
      return;
    }

    chrome.tabs.query({}, (tabs) => {
      // Consume lastError if any to avoid unchecked warnings
      if (chrome.runtime?.lastError) return;

      const quotexTab = tabs.find((t) => {
        try {
          const u = new URL(t.url || "");
          return u.hostname.includes("quotex.com") || u.hostname.includes("qxbroker.com");
        } catch {
          return false;
        }
      });

      if (quotexTab) {
        tabDot.className = "dot dot-green";
        tabText.textContent = quotexTab.active
          ? "Quotex Chart Connected (Active Tab)"
          : "Quotex Chart Connected (Background Tab)";
        linkOpenQuotex.classList.add("hidden");
      } else {
        tabDot.className = "dot dot-amber";
        tabText.textContent = "Quotex Tab Not Detected";
        linkOpenQuotex.classList.remove("hidden");
      }
    });
  }

  // Probe open Web Terminal tabs to synchronize access_token automatically
  function checkWebSession(silent = false) {
    if (!silent && iconRefresh) {
      iconRefresh.classList.add("spinning");
      textCheckSession.textContent = "Checking Session...";
    }

    if (!chrome?.tabs?.query) {
      if (!silent && iconRefresh) {
        iconRefresh.classList.remove("spinning");
      }
      return;
    }

    chrome.tabs.query({}, (tabs) => {
      // Consume lastError if any
      if (chrome.runtime?.lastError) return;

      const apexTab = tabs.find((t) => {
        try {
          const u = new URL(t.url || "");
          return (
            (u.hostname === "localhost" || u.hostname === "127.0.0.1") &&
            u.port === "3000"
          );
        } catch {
          return false;
        }
      });

      if (!apexTab?.id) {
        if (!silent && iconRefresh) {
          iconRefresh.classList.remove("spinning");
          textCheckSession.textContent = "Open localhost:3000";
          setTimeout(() => {
            textCheckSession.textContent = "Check Web Session";
          }, 2000);
        }
        return;
      }

      // First try sending a message, but ALWAYS consume chrome.runtime.lastError
      chrome.tabs.sendMessage(apexTab.id, { type: "APEX_GET_WEB_AUTH" }, (response) => {
        const err = chrome.runtime?.lastError; // Consuming lastError prevents "Unchecked runtime.lastError"!

        if (!silent && iconRefresh) {
          iconRefresh.classList.remove("spinning");
        }

        // If the tab was open before extension reloaded, content script might not be initialized yet.
        // Fallback directly to chrome.scripting to read localStorage safely!
        if (err || !response) {
          if (chrome?.scripting?.executeScript) {
            chrome.scripting
              .executeScript({
                target: { tabId: apexTab.id },
                func: () => {
                  try {
                    const token = localStorage.getItem("access_token");
                    const userStr = localStorage.getItem("user");
                    return {
                      access_token: token || null,
                      user: userStr ? JSON.parse(userStr) : null,
                    };
                  } catch {
                    return { access_token: null, user: null };
                  }
                },
              })
              .then((results) => {
                const data = results?.[0]?.result;
                if (data?.access_token) {
                  chrome.storage.local.set(
                    {
                      access_token: data.access_token,
                      user: data.user || null,
                      is_authenticated: true,
                      is_monitoring: true,
                    },
                    () => {
                      sessionUser.textContent = data.user?.email || "Authenticated";
                      renderMonitoringState(true);
                      switchView("main");
                    }
                  );
                } else if (!silent) {
                  textCheckSession.textContent = "No Active Session";
                  setTimeout(() => {
                    textCheckSession.textContent = "Check Web Session";
                  }, 2000);
                }
              })
              .catch(() => {
                // Ignore any scripting permission issues on chrome:// or restricted pages
                if (!silent) {
                  textCheckSession.textContent = "No Active Session";
                  setTimeout(() => {
                    textCheckSession.textContent = "Check Web Session";
                  }, 2000);
                }
              });
            return;
          }

          if (!silent) {
            textCheckSession.textContent = "No Active Session";
            setTimeout(() => {
              textCheckSession.textContent = "Check Web Session";
            }, 2000);
          }
          return;
        }

        if (response?.access_token) {
          chrome.storage.local.set(
            {
              access_token: response.access_token,
              user: response.user || null,
              is_authenticated: true,
              is_monitoring: true,
            },
            () => {
              sessionUser.textContent = response.user?.email || "Authenticated";
              renderMonitoringState(true);
              switchView("main");
            }
          );
        } else if (!silent) {
          textCheckSession.textContent = "No Active Session";
          setTimeout(() => {
            textCheckSession.textContent = "Check Web Session";
          }, 2000);
        }
      });
    });
  }

  // Switch between Auth view and Main view
  function switchView(viewName) {
    if (viewName === "main") {
      authView.classList.add("hidden");
      mainView.classList.remove("hidden");
      btnLogout.classList.remove("hidden");
      checkBrokerTabStatus();
    } else {
      mainView.classList.add("hidden");
      authView.classList.remove("hidden");
      btnLogout.classList.add("hidden");
    }
  }

  // Load Initial State from chrome.storage.local
  function initializeState() {
    chrome.storage.local.get(
      [
        "access_token",
        "is_authenticated",
        "is_monitoring",
        "active_pair",
        "user",
      ],
      (data) => {
        if (data.access_token) {
          sessionUser.textContent = data.user?.email || data.user?.full_name || "Authenticated";
          renderMonitoringState(data.is_monitoring ?? true);
          updateAssetDisplay(data.active_pair);
          switchView("main");
        } else {
          // Probe open tabs silently in case user just logged in
          checkWebSession(true);
          switchView("auth");
        }
      }
    );
  }

  // Listen for storage changes in real time (e.g. from web_auth_sync or service_worker)
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local") return;

    if (changes.access_token) {
      if (changes.access_token.newValue) {
        sessionUser.textContent = "Authenticated";
        renderMonitoringState(true);
        switchView("main");
      } else {
        switchView("auth");
      }
    }
    if (changes.user && changes.user.newValue?.email) {
      sessionUser.textContent = changes.user.newValue.email;
    }
    if (changes.active_pair) {
      updateAssetDisplay(changes.active_pair.newValue);
    }
    if (changes.is_monitoring) {
      renderMonitoringState(changes.is_monitoring.newValue);
    }
    if (changes.is_authenticated) {
      if (changes.is_authenticated.newValue) {
        switchView("main");
      } else {
        switchView("auth");
      }
    }
  });

  // Handle Check Session Button in Auth View
  if (btnCheckSession) {
    btnCheckSession.addEventListener("click", () => {
      checkWebSession(false);
    });
  }

  // Handle Toggle Monitoring Button
  btnToggleMonitoring.addEventListener("click", () => {
    const nextState = !currentMonitoringState;
    renderMonitoringState(nextState);

    chrome.storage.local.set({ is_monitoring: nextState });

    // Inform service worker and safely consume lastError
    chrome.runtime.sendMessage(
      {
        type: "APEX_TOGGLE_MONITORING",
        status: nextState,
      },
      () => {
        const _ = chrome.runtime?.lastError;
      }
    );
  });

  // Handle Logout / Disconnect Session
  btnLogout.addEventListener("click", () => {
    if (confirm("Disconnect extension session?")) {
      chrome.storage.local.set(
        {
          access_token: null,
          user: null,
          is_authenticated: false,
          is_monitoring: false,
        },
        () => {
          switchView("auth");
        }
      );
    }
  });

  // Handle all external links via chrome.tabs.create for 100% CSP compliance
  document.querySelectorAll("a").forEach((link) => {
    link.addEventListener("click", (e) => {
      const href = link.getAttribute("href");
      if (href && (href.startsWith("http://") || href.startsWith("https://"))) {
        e.preventDefault();
        chrome.tabs.create({ url: href });
      }
    });
  });

  // Run initial state setup
  initializeState();
});
