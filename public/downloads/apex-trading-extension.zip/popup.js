chrome.storage.local.get(["activeTelemetry"], (result) => {
  const el = document.getElementById("active-asset");
  if (result.activeTelemetry && result.activeTelemetry.pair) {
    el.textContent = `${result.activeTelemetry.pair} (${result.activeTelemetry.market})`;
  } else {
    el.textContent = "Waiting for broker tab...";
  }
});
