// Apex Signal Trading - Market Sync Content Script
console.log("[Apex Sync] Content script initialized on:", window.location.hostname);

function detectActivePair() {
  let pair = null;
  let isOTC = false;

  // Pocket Option DOM selectors
  const poAsset = document.querySelector(".current-symbol, .assets-item--active, [data-qa='asset-name']");
  if (poAsset) {
    pair = poAsset.textContent?.trim() || "";
    isOTC = pair.toUpperCase().includes("OTC");
  }

  // Quotex DOM selectors
  const qxAsset = document.querySelector(".asset-select__current-name, .header-asset-name, .current-asset");
  if (!pair && qxAsset) {
    pair = qxAsset.textContent?.trim() || "";
    isOTC = pair.toUpperCase().includes("OTC") || document.querySelector(".asset-select__otc") !== null;
  }

  // Fallback title detection
  if (!pair && document.title) {
    const titleMatch = document.title.match(/([A-Z]{3}\/[A-Z]{3}|[A-Z]{6})/i);
    if (titleMatch) {
      pair = titleMatch[0];
      isOTC = document.title.toUpperCase().includes("OTC");
    }
  }

  if (pair) {
    const cleanPair = pair.replace(/[^A-Za-z0-9\/]/g, "").toUpperCase();
    chrome.runtime.sendMessage({
      type: "APEX_PAIR_DETECTED",
      payload: {
        pair: cleanPair,
        isOTC: isOTC,
        market: isOTC ? "OTC" : "Regular",
        timestamp: Date.now(),
        sourceUrl: window.location.hostname
      }
    }).catch(() => {
      // Background receiver not yet ready or inactive
    });
  }
}

const observer = new MutationObserver(() => {
  detectActivePair();
});

if (document.body) {
  observer.observe(document.body, { childList: true, subtree: true, characterData: true });
} else {
  document.addEventListener("DOMContentLoaded", () => {
    observer.observe(document.body, { childList: true, subtree: true, characterData: true });
  });
}

detectActivePair();
setInterval(detectActivePair, 3000);
