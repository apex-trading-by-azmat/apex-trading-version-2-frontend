(() => {
    const MESSAGE_SOURCE = "quotex-chart-capture";
    const targetEvents = new Set([
        "quotes/stream", 
        "depth/change", "s_balance/list","instruments/list", "history/list/v2",
        "depth/follow","instruments/update", "s_drawing/load",
    "indicator/list",
"drawing/load",
"pending/list",
"balance/list",
"orders/open",
"s_orders/open",
"orders/opened/list",
"orders/closed/list",
"settings/store",
"instruments/update",
"depth/unfollow",
"depth/follow",
    ]);
    const pendingPackets = {
        client_to_server: new WeakMap(),
        server_to_client: new WeakMap()
    };
    const frameQueues = {
        client_to_server: new WeakMap(),
        server_to_client: new WeakMap()
    };
    const OriginalWebSocket = window.WebSocket;

    function replacePlaceholders(value, attachments) {
        if (Array.isArray(value)) {
            return value.map(item => replacePlaceholders(item, attachments));
        }

        if (value && typeof value === "object") {
            if (value._placeholder === true) {
                return attachments[value.num];
            }

            return Object.fromEntries(
                Object.entries(value).map(([key, item]) => [
                    key,
                    replacePlaceholders(item, attachments)
                ])
            );
        }

        return value;
    }

    function emitEvent(event, payload, direction) {
        window.postMessage({
            source: MESSAGE_SOURCE,
            type: "quotex-ws-event",
            event,
            direction,
            payload,
            received_at: new Date().toISOString()
        }, window.location.origin);
    }

    function decodeAttachment(data) {
        let bytes = new Uint8Array(data);
        if (bytes[0] === 0x04) {
            bytes = bytes.subarray(1);
        }

        return JSON.parse(new TextDecoder().decode(bytes));
    }

    function readEventPacket(packetData) {
        try {
            const packet = JSON.parse(packetData);
            if (!Array.isArray(packet) || !targetEvents.has(packet[0])) {
                return null;
            }

            return { event: packet[0], payload: packet[1] };
        } catch (error) {
            console.error("WebSocket event header decoding failed:", error);
            return null;
        }
    }

    async function processFrame(socket, data, direction) {
        const socketPackets = pendingPackets[direction];

        if (typeof data === "string") {
            const binaryHeader = data.match(/^45(\d+)-(.*)$/s);
            if (binaryHeader) {
                const packet = readEventPacket(binaryHeader[2]);
                const attachmentCount = Number(binaryHeader[1]);
                if (!packet || !Number.isSafeInteger(attachmentCount)) {
                    socketPackets.delete(socket);
                    return;
                }

                if (attachmentCount === 0) {
                    emitEvent(packet.event, packet.payload, direction);
                    socketPackets.delete(socket);
                } else {
                    socketPackets.set(socket, {
                        ...packet,
                        remaining: attachmentCount,
                        attachments: []
                    });
                }
                return;
            }

            const eventPacket = data.match(/^42(.*)$/s);
            if (eventPacket) {
                const packet = readEventPacket(eventPacket[1]);
                if (packet) {
                    emitEvent(packet.event, packet.payload, direction);
                }
            }
            return;
        }

        const pending = socketPackets.get(socket);
        if (!pending) {
            return;
        }

        try {
            let buffer;
            if (data instanceof ArrayBuffer) {
                buffer = data;
            } else if (data instanceof Blob) {
                buffer = await data.arrayBuffer();
            } else if (ArrayBuffer.isView(data)) {
                buffer = data.buffer.slice(
                    data.byteOffset,
                    data.byteOffset + data.byteLength
                );
            } else {
                return;
            }

            pending.attachments.push(decodeAttachment(buffer));
            pending.remaining--;
            if (pending.remaining === 0) {
                emitEvent(
                    pending.event,
                    replacePlaceholders(pending.payload, pending.attachments),
                    direction
                );
                socketPackets.delete(socket);
            }
        } catch (error) {
            socketPackets.delete(socket);
            console.error("WebSocket attachment decoding failed:", error);
        }
    }

    function enqueueFrame(socket, data, direction) {
        const queues = frameQueues[direction];
        const previous = queues.get(socket) || Promise.resolve();
        const current = previous
            .then(() => processFrame(socket, data, direction))
            .catch(error => {
                console.error("WebSocket frame processing failed:", error);
            });
        queues.set(socket, current);
    }

    const originalSend = OriginalWebSocket.prototype.send;
    OriginalWebSocket.prototype.send = function (data) {
        const result = Reflect.apply(originalSend, this, [data]);
        enqueueFrame(this, data, "client_to_server");
        return result;
    };

    window.WebSocket = new Proxy(OriginalWebSocket, {
        construct(target, args) {
            const socket = Reflect.construct(target, args);
            socket.addEventListener("message", event => {
                enqueueFrame(socket, event.data, "server_to_client");
            });
            return socket;
        }
    });

    console.log("Quotex WebSocket capture started.");
})();
