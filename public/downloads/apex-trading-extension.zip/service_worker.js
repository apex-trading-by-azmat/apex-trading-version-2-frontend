const FASTAPI_URL = "https://apex-api.udyanasoft.com:8001/extension/events/";
const ALLOWED_EVENTS = new Set([
  "quotes/stream",
  "depth/change",
  "s_balance/list",
  "instruments/list",
  "history/list/v2",
  "depth/follow",
  "instruments/update",
  "s_drawing/load",
  "indicator/list",
  "drawing/load",
  "pending/list",
  "balance/list",
  "orders/open",
  "s_orders/open",
  "orders/opened/list",
  "orders/closed/list",
  "settings/store",
  "instruments/update",
  "depth/unfollow",
  "depth/follow",
]);
const ALLOWED_HOSTS = new Set(["quotex.com", "qxbroker.com"]);

function isAllowedPage(url) {
  try {
    const { hostname, protocol } = new URL(url);
    return (
      protocol === "https:" &&
      [...ALLOWED_HOSTS].some(
        (host) => hostname === host || hostname.endsWith(`.${host}`),
      )
    );
  } catch {
    return false;
  }
}

async function ensureAuthenticated() {
  const storage = await chrome.storage.local.get(["access_token"]);
  if (storage.access_token) return storage.access_token;

  // Try to sync from open web app tabs automatically
  try {
    const tabs = await chrome.tabs.query({
      url: ["http://localhost:3000/*", "http://127.0.0.1:3000/*"],
    });
    for (const tab of tabs) {
      if (tab.id) {
        const authData = await chrome.tabs
          .sendMessage(tab.id, { type: "APEX_GET_WEB_AUTH" })
          .catch(() => null);
        if (authData?.access_token) {
          await chrome.storage.local.set({
            access_token: authData.access_token,
            user: authData.user || null,
            is_authenticated: true,
            is_monitoring: true,
          });
          console.log("[Apex Signal] Auto-synchronized session from web app tab.");
          return authData.access_token;
        }
      }
    }
  } catch {
    // Ignore tab query errors
  }
  return null;
}

async function forwardEvent(message, sender) {
  if (!sender.tab || !sender.url || !isAllowedPage(sender.url)) {
    throw new Error("Messages are accepted only from a supported chart page.");
  }

  if (!ALLOWED_EVENTS.has(message.event)) {
    return { ok: false, ignored: true, reason: "Unsupported event" };
  }

  // Ensure access_token is present or auto-synced
  const token = await ensureAuthenticated();

  // Check if monitoring is paused by user in popup UI or unauthenticated
  const storage = await chrome.storage.local.get([
    "is_monitoring",
    "access_token",
    "session_id",
    "events_count",
    "fastapi_url",
  ]);

  const activeToken = token || storage.access_token;

  if (!activeToken) {
    console.warn(
      "[Apex Signal] Received chart tick, but extension is not authenticated. Please log in at http://localhost:3000.",
    );
    return {
      ok: false,
      unauthenticated: true,
      error: "Extension not authenticated. Log in on web terminal.",
    };
  }

  if (storage.is_monitoring === false) {
    return { ok: false, paused: true, error: "Monitoring paused." };
  }

  const endpoint =
    storage.fastapi_url && storage.fastapi_url.startsWith("https://")
      ? storage.fastapi_url
      : FASTAPI_URL;

  const payloadData = {
    event: message.event,
    direction: message.direction,
    payload: message.payload,
    received_at: message.received_at,
    ...(storage.session_id ? { session_id: storage.session_id } : {}),
  };

  const response = await fetch(endpoint, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${activeToken}`,
    },
    body: JSON.stringify(payloadData),
  });

  if (!response.ok) {
    const detail = (await response.text()).slice(0, 300);
    console.error(
      `[Apex Signal] Backend error HTTP ${response.status}: ${detail}`,
    );
    throw new Error(
      `FastAPI returned HTTP ${response.status}${detail ? `: ${detail}` : ""}`,
    );
  }

  const responseData = await response.json().catch(() => null);

  // Update telemetry state for the popup UI
  const nextCount = (storage.events_count || 0) + 1;
  let detectedPair = null;
  if (message.payload && typeof message.payload === "object") {
    detectedPair =
      message.payload.asset ||
      message.payload.symbol ||
      message.payload.currency ||
      null;
    if (
      !detectedPair &&
      Array.isArray(message.payload.data) &&
      message.payload.data[0]
    ) {
      detectedPair = message.payload.data[0].asset || null;
    }
  }

  const newSessionId = responseData?.session_id || storage.session_id;

  chrome.storage.local.set({
    events_count: nextCount,
    last_event_at: new Date().toISOString(),
    last_event_name: message.event,
    ...(newSessionId ? { session_id: newSessionId } : {}),
    ...(detectedPair ? { active_pair: detectedPair } : {}),
  });

  return {
    ok: true,
    session_id: newSessionId,
    event_name: message.event,
  };
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  // Web app auth bridge sync
  if (message?.type === "APEX_WEB_AUTH_SYNC") {
    const { access_token, user } = message.payload || {};
    if (access_token) {
      chrome.storage.local.set({
        access_token: access_token,
        user: user || null,
        is_authenticated: true,
      });
    } else {
      chrome.storage.local.set({
        access_token: null,
        user: null,
        is_authenticated: false,
      });
    }
    sendResponse({ ok: true });
    return true;
  }

  // Popup status query
  if (message?.type === "APEX_GET_STATUS") {
    chrome.storage.local.get(
      [
        "license_key",
        "is_authenticated",
        "is_monitoring",
        "events_count",
        "last_event_at",
        "last_event_name",
        "active_pair",
        "fastapi_url",
        "session_id",
      ],
      (res) => sendResponse({ ok: true, data: res }),
    );
    return true;
  }

  // Pinned tabs sync handler
  if (message?.type === "APEX_SYNC_PINNED_TABS") {
    chrome.storage.local.get(
      ["access_token", "session_id", "fastapi_url"],
      async (storage) => {
        if (!storage.access_token) {
          sendResponse({ ok: false, error: "Unauthenticated" });
          return;
        }
        const baseUrl = (storage.fastapi_url || FASTAPI_URL).replace(
          "/extension/events/",
          "",
        );
        const pinnedEndpoint = `${baseUrl}/extension/tabs/pinned/`;
        try {
          const resp = await fetch(pinnedEndpoint, {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${storage.access_token}`,
            },
            body: JSON.stringify({
              session_id: storage.session_id || message.payload?.session_id || "",
              pinned_assets: message.payload?.pinned_assets || [],
              active_asset: message.payload?.active_asset || "",
            }),
          });
          const data = await resp.text();
          sendResponse({ ok: resp.ok, data });
        } catch (err) {
          sendResponse({ ok: false, error: err.message });
        }
      },
    );
    return true;
  }

  // Popup monitoring toggle
  if (message?.type === "APEX_TOGGLE_MONITORING") {
    const newStatus = !!message.status;
    chrome.storage.local.set({ is_monitoring: newStatus }, () => {
      sendResponse({ ok: true, is_monitoring: newStatus });
    });
    return true;
  }

  // WebSocket event from chart page
  if (!message || message.type !== "quotex-ws-event") {
    return false;
  }

  forwardEvent(message, sender).then(
    () => sendResponse({ ok: true }),
    (error) => {
      console.error("Could not forward WebSocket event:", error);
      sendResponse({ ok: false, error: error.message });
    },
  );

  return true;
});
