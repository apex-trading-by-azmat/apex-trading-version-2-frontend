# Apex Signal Trading — Quotex WebSocket Capture Extension

The extension captures and forwards allowlisted Socket.IO events sent and received by Quotex / QxBroker chart pages to the local Apex FastAPI ingest endpoint.

---

## Automated Web Auth Bridge (Zero Manual License Input)

The extension no longer requires manual license key typing:
1. When a user signs in to the Apex Trading Terminal (`http://localhost:3000/auth/login`), the `access_token` stored in the web application's `localStorage` is automatically synced to the extension via `web_auth_sync.js`.
2. As long as `access_token` exists, the extension automatically displays the **Main Monitoring Dashboard** with:
   - Interactive **START / STOP MONITORING** button
   - Live Quotex Tab detection (`quotex.com` / `qxbroker.com`)
   - Real-time detected chart asset (`EUR/USD (OTC)`, `GBP/USD`)
   - Instant links to the Live Signals Terminal and Web Dashboard
3. If the user logs out from the web app (or `access_token` is cleared), the extension automatically returns to the Standby view and pauses packet forwarding.

---

## Extension File Structure

- `manifest.json`: Manifest V3 configuration with content scripts for Quotex and the Apex web terminal.
- `web_auth_sync.js`: Content script that bridges `access_token` from web app `localStorage` to `chrome.storage.local`.
- `websocket_capture.js`: Injected into chart page main world to capture Socket.IO packets.
- `content_script.js`: Bridges DOM messages to the background service worker.
- `service_worker.js`: Forwards captured packets to FastAPI only while `access_token` is present and monitoring is active.
- `popup.html`, `popup.css`, `popup.js`: Terminal popup interface.

---

## How to Install in Chrome

1. Open `chrome://extensions/` in Google Chrome.
2. Turn ON **Developer mode** in the top-right corner.
3. Click **Load unpacked** (top-left) and select this folder (`quotex_chart_capture_extension`).
4. Log in on your web terminal (`http://localhost:3000/auth/login`).
5. Open the extension popup — it will automatically detect your session and show the **START MONITORING** button!
