const PAGE_MESSAGE_SOURCE = "quotex-chart-capture";

console.log(
  "%c[Apex Signal]%c Quotex Capture script initialized on chart page.",
  "color: #3b82f6; font-weight: bold;",
  "color: inherit;"
);

let loggedAuthWarning = false;
let tickCount = 0;

function handleExtensionError(error) {
  if (/extension context invalidated/i.test(error?.message || "")) {
    window.removeEventListener("message", handlePageMessage);
    console.warn(
      "[Apex Signal] Extension was reloaded. Please refresh this chart page to resume capture."
    );
    return;
  }
  console.error("[Apex Signal] Could not contact background service worker:", error);
}

function handlePageMessage(event) {
  if (event.source !== window) {
    return;
  }

  const message = event.data;
  if (
    !message ||
    message.source !== PAGE_MESSAGE_SOURCE ||
    message.type !== "quotex-ws-event"
  ) {
    return;
  }

  try {
    chrome.runtime.sendMessage(message, (response) => {
      const lastErr = chrome.runtime?.lastError;
      if (lastErr) return;

      if (response && response.unauthenticated) {
        if (!loggedAuthWarning) {
          loggedAuthWarning = true;
          console.warn(
            "%c[Apex Signal]%c Extension not yet authenticated. Please log in on the Web Terminal (http://localhost:3000/auth/login) or open the Apex extension popup.",
            "color: #f59e0b; font-weight: bold;",
            "color: inherit;"
          );
        }
      } else if (response && response.ok) {
        tickCount++;
        // Log the first tick and every 25th tick to confirm live telemetry without flooding
        if (tickCount === 1 || tickCount % 25 === 0) {
          console.log(
            `%c[Apex Signal]%c Streaming chart tick: ${message.event} -> Backend 202 Accepted (Session: ${response.session_id || "active"}) [ticks: ${tickCount}]`,
            "color: #10b981; font-weight: bold;",
            "color: inherit;"
          );
        }
      } else if (response && response.error) {
        console.warn("[Apex Signal] Forwarding report:", response.error);
      }
    });
  } catch (error) {
    handleExtensionError(error);
  }
}

window.addEventListener("message", handlePageMessage);
