// Apex Signal Trading - Web App Auth Bridge
// Automatically syncs access_token from web app's localStorage to the extension

(function () {
  function getWebAuthData() {
    try {
      const token = localStorage.getItem("access_token");
      const userStr = localStorage.getItem("user");
      let user = null;
      if (userStr) {
        try {
          user = JSON.parse(userStr);
        } catch {
          // Ignore parse errors
        }
      }
      return { access_token: token || null, user };
    } catch {
      return { access_token: null, user: null };
    }
  }

  function broadcastAuthSync() {
    const data = getWebAuthData();
    try {
      chrome.runtime.sendMessage(
        {
          type: "APEX_WEB_AUTH_SYNC",
          payload: data,
        },
        () => {
          // Always consume chrome.runtime.lastError to prevent "Receiving end does not exist" errors
          const _ = chrome.runtime?.lastError;
        }
      );
    } catch {
      // Ignore
    }
  }

  // Answer direct queries from popup or service worker
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request?.type === "APEX_GET_WEB_AUTH") {
      sendResponse(getWebAuthData());
      return true;
    }
  });

  // Initial sync on page load
  broadcastAuthSync();

  // Listen for storage events (e.g. login or logout in other tabs)
  window.addEventListener("storage", (e) => {
    if (e.key === "access_token" || e.key === "user") {
      broadcastAuthSync();
    }
  });

  // Polling fallback to detect local login/logout transitions
  let lastToken = typeof localStorage !== "undefined" ? localStorage.getItem("access_token") : null;
  setInterval(() => {
    try {
      const currentToken = localStorage.getItem("access_token");
      if (currentToken !== lastToken) {
        lastToken = currentToken;
        broadcastAuthSync();
      }
    } catch {
      // Ignore
    }
  }, 2000);
})();
