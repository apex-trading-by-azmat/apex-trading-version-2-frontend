=========================================================
 Apex Signal Trading — Chrome Extension Setup Guide
 Version: 1.0.0 (Manifest V3)
=========================================================

How to install this extension in Google Chrome:

1. Extract this entire zip file to a permanent folder on your computer
   (for example: C:\Users\<YourUser>\Downloads\apex-trading-extension).

2. Open Google Chrome and enter the following into your address bar:
   chrome://extensions/

3. In the top-right corner of the Extensions page, switch ON:
   [Developer mode]

4. In the top-left corner, click:
   [Load unpacked]

5. Select the extracted "apex-trading-extension" folder.

6. The extension is now installed!
   Click the puzzle piece icon in Chrome's top toolbar and pin
   "Apex Signal Trading" so it stays visible.

7. Open your broker platform (Pocket Option, Quotex, Olymp Trade, Binomo).
   The extension will automatically read your active chart asset
   (including OTC status) and sync it directly to the Apex Trading Terminal.

Need support? Visit http://localhost:3000/dashboard/help
=========================================================
