// Apex Signal Trading - Background Service Worker
chrome.runtime.onInstalled.addListener(() => {
  console.log("[Apex Sync] Extension installed.");
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "APEX_PAIR_DETECTED") {
    chrome.storage.local.set({ activeTelemetry: message.payload });
    console.log("[Apex Sync] Synchronized pair:", message.payload.pair, message.payload.market);
  }
  sendResponse({ status: "ok" });
  return true;
});
